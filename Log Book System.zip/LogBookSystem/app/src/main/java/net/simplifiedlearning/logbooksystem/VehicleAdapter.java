package net.simplifiedlearning.logbooksystem;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import java.util.List;


public class VehicleAdapter extends RecyclerView.Adapter<VehicleAdapter.ProductViewHolder> {


    private Context mCtx;
    private List<Vehicle> vehicleList;

    public VehicleAdapter(Context mCtx, List<Vehicle> vehicleList) {
        this.mCtx = mCtx;
        this.vehicleList = vehicleList;
    }

    @Override
    public ProductViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(mCtx);
        View view = inflater.inflate(R.layout.vehicle_list, null);
        return new ProductViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ProductViewHolder holder, int position) {
        Vehicle vehicle = vehicleList.get(position);


        holder.textBrand.setText(vehicle.getbrand());
        holder.textModel.setText(vehicle.getmodel());
        holder.textRegistern.setText(String.valueOf(vehicle.getregistern()));
        holder.textDepartment.setText(String.valueOf(vehicle.getdepartment()));
    }

    @Override
    public int getItemCount() {
        return vehicleList.size();
    }

    class ProductViewHolder extends RecyclerView.ViewHolder {

        TextView textBrand, textModel, textRegistern, textDepartment;

        public ProductViewHolder(View itemView) {
            super(itemView);

            textBrand = itemView.findViewById(R.id.textBrand);
            textModel = itemView.findViewById(R.id.textModel);
            textRegistern = itemView.findViewById(R.id.textRegistern);
            textDepartment = itemView.findViewById(R.id.textDepartment);
        }
    }
}