package net.simplifiedlearning.logbooksystem;

public class Vehicle {
    private String brand;
    private String model;
    private String registern;
    private String department;


    public Vehicle(String brand, String model, String registern, String department) {
        this.brand = brand;
        this.model = model;
        this.registern = registern;
        this.department = department;

    }

    public String getbrand() {
        return brand;
    }

    public String getmodel() {
        return model;
    }

    public String getregistern() {
        return registern;
    }

    public String getdepartment() {
        return department;
    }




}